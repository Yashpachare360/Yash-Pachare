import { Trophy, Users, Award, Calendar } from 'lucide-react';
import ownerImg from 'figma:asset/61486a7e3bec3ee369312b5c51111dde535536c0.png';

interface HomePageProps {
  onNavigate: (page: string) => void;
}

export function HomePage({ onNavigate }: HomePageProps) {
  const features = [
    {
      icon: Trophy,
      title: 'Epic Tournaments',
      description: 'Join competitive tournaments with amazing prizes'
    },
    {
      icon: Users,
      title: 'Global Community',
      description: 'Connect with gamers from around the world'
    },
    {
      icon: Award,
      title: 'Pro Level Play',
      description: 'Compete at the highest level of gaming'
    },
    {
      icon: Calendar,
      title: 'Regular Events',
      description: 'New tournaments and events every week'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 z-0"
          style={{
            backgroundImage: 'url(https://images.unsplash.com/photo-1759701546851-1d903ac1a2e2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlc3BvcnRzJTIwZ2FtaW5nJTIwdG91cm5hbWVudHxlbnwxfHx8fDE3NjcyNDY2OTh8MA&ixlib=rb-4.1.0&q=80&w=1080)',
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/60 to-black"></div>
        </div>

        <div className="relative z-10 text-center px-4 max-w-5xl">
          <h1 className="text-6xl md:text-8xl mb-6 bg-gradient-to-r from-cyan-400 to-blue-600 bg-clip-text text-transparent">
            Welcome to EZY
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-8">
            The Ultimate Gaming Tournament Platform
          </p>
          <button
            onClick={() => onNavigate('register')}
            className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white px-8 py-4 rounded-lg hover:shadow-lg hover:shadow-cyan-500/50 transition-all"
          >
            Register Now
          </button>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-black to-gray-900">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl md:text-5xl text-center mb-16 text-cyan-400">
            Why Choose EZY?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="bg-gray-800/50 backdrop-blur-sm border border-cyan-500/30 rounded-lg p-6 hover:border-cyan-400/60 transition-all hover:transform hover:scale-105"
              >
                <feature.icon className="w-12 h-12 text-cyan-400 mb-4" />
                <h3 className="text-xl mb-2">{feature.title}</h3>
                <p className="text-gray-400">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Owner Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-gray-900 to-black">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl md:text-5xl text-center mb-16 text-cyan-400">
            Meet The Founder
          </h2>
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="flex-shrink-0">
              <img
                src={ownerImg}
                alt="Founder"
                className="w-64 h-64 md:w-80 md:h-80 rounded-lg object-cover shadow-2xl shadow-cyan-500/30 border-2 border-cyan-400/50"
              />
            </div>
            <div className="flex-1 text-center md:text-left">
              <h3 className="text-3xl mb-4">Passionate About Gaming</h3>
              <p className="text-gray-400 text-lg leading-relaxed mb-6">
                With years of experience in competitive gaming and tournament organization, 
                our founder created EZY to bring together the best gaming community. 
                We believe in fair play, exciting competitions, and creating memorable gaming experiences.
              </p>
              <p className="text-gray-400 text-lg leading-relaxed">
                Join us on this incredible journey to become the best in esports. 
                Whether you're a casual player or a pro, there's a place for you at EZY.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-black to-gray-900">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl mb-6">
            Ready to Compete?
          </h2>
          <p className="text-xl text-gray-400 mb-8">
            Join thousands of gamers in the most exciting tournaments
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => onNavigate('tournament')}
              className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white px-8 py-4 rounded-lg hover:shadow-lg hover:shadow-cyan-500/50 transition-all"
            >
              View Tournaments
            </button>
            <button
              onClick={() => onNavigate('contact')}
              className="border border-cyan-400 text-cyan-400 px-8 py-4 rounded-lg hover:bg-cyan-400/10 transition-all"
            >
              Contact Us
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
