import { Calendar, Users, Trophy, DollarSign } from 'lucide-react';

interface TournamentPageProps {
  onNavigate: (page: string) => void;
}

export function TournamentPage({ onNavigate }: TournamentPageProps) {
  const tournaments = [
    {
      id: 1,
      title: 'Summer Championship 2026',
      game: 'Multi-Game Tournament',
      date: 'June 15 - June 20, 2026',
      participants: '128 Teams',
      prize: '$50,000',
      status: 'Registration Open',
      image: 'https://images.unsplash.com/photo-1759701546851-1d903ac1a2e2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlc3BvcnRzJTIwZ2FtaW5nJTIwdG91cm5hbWVudHxlbnwxfHx8fDE3NjcyNDY2OTh8MA&ixlib=rb-4.1.0&q=80&w=1080'
    },
    {
      id: 2,
      title: 'Weekly Showdown',
      game: 'Battle Royale',
      date: 'Every Saturday',
      participants: '64 Players',
      prize: '$5,000',
      status: 'Ongoing',
      image: 'https://images.unsplash.com/photo-1567027757540-7b572280fa22?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1pbmclMjBjb250cm9sbGVyJTIwbmVvbnxlbnwxfHx8fDE3NjcyOTI2OTR8MA&ixlib=rb-4.1.0&q=80&w=1080'
    },
    {
      id: 3,
      title: 'Pro League Season 3',
      game: 'FPS Championship',
      date: 'March 1 - May 31, 2026',
      participants: '32 Teams',
      prize: '$100,000',
      status: 'Coming Soon',
      image: 'https://images.unsplash.com/photo-1553492206-f609eddc33dd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21wZXRpdGl2ZSUyMGdhbWluZyUyMGFyZW5hfGVufDF8fHx8MTc2NzI5MjY5NHww&ixlib=rb-4.1.0&q=80&w=1080'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Registration Open':
        return 'bg-green-500/20 text-green-400 border-green-500/50';
      case 'Ongoing':
        return 'bg-blue-500/20 text-blue-400 border-blue-500/50';
      case 'Coming Soon':
        return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50';
      default:
        return 'bg-gray-500/20 text-gray-400 border-gray-500/50';
    }
  };

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="relative py-20 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-cyan-500/10 to-transparent"></div>
        <div className="relative z-10 max-w-7xl mx-auto text-center">
          <h1 className="text-5xl md:text-7xl mb-6 bg-gradient-to-r from-cyan-400 to-blue-600 bg-clip-text text-transparent">
            Tournaments
          </h1>
          <p className="text-xl text-gray-400">
            Compete in exciting tournaments and win amazing prizes
          </p>
        </div>
      </section>

      {/* Tournaments Grid */}
      <section className="py-12 px-4 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-8">
          {tournaments.map((tournament) => (
            <div
              key={tournament.id}
              className="bg-gray-800/50 backdrop-blur-sm border border-cyan-500/30 rounded-lg overflow-hidden hover:border-cyan-400/60 transition-all hover:transform hover:scale-105"
            >
              {/* Tournament Image */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={tournament.image}
                  alt={tournament.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent"></div>
                <div className={`absolute top-4 right-4 px-3 py-1 rounded-full border ${getStatusColor(tournament.status)}`}>
                  {tournament.status}
                </div>
              </div>

              {/* Tournament Info */}
              <div className="p-6">
                <h3 className="text-2xl mb-2">{tournament.title}</h3>
                <p className="text-cyan-400 mb-4">{tournament.game}</p>

                <div className="space-y-3">
                  <div className="flex items-center text-gray-400">
                    <Calendar className="w-5 h-5 mr-3 text-cyan-400" />
                    {tournament.date}
                  </div>
                  <div className="flex items-center text-gray-400">
                    <Users className="w-5 h-5 mr-3 text-cyan-400" />
                    {tournament.participants}
                  </div>
                  <div className="flex items-center text-gray-400">
                    <DollarSign className="w-5 h-5 mr-3 text-cyan-400" />
                    Prize Pool: {tournament.prize}
                  </div>
                </div>

                <button
                  onClick={() => onNavigate('register')}
                  className="w-full mt-6 bg-gradient-to-r from-cyan-500 to-blue-600 text-white px-6 py-3 rounded-lg hover:shadow-lg hover:shadow-cyan-500/50 transition-all"
                >
                  Register Now
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Tournament Format Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-transparent to-gray-900/50">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl text-center mb-12 text-cyan-400">
            Tournament Format
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gray-800/50 border border-cyan-500/30 rounded-lg p-6 text-center">
              <Trophy className="w-16 h-16 text-cyan-400 mx-auto mb-4" />
              <h3 className="text-2xl mb-3">Single Elimination</h3>
              <p className="text-gray-400">
                Fast-paced bracket style tournaments where every match counts
              </p>
            </div>
            <div className="bg-gray-800/50 border border-cyan-500/30 rounded-lg p-6 text-center">
              <Users className="w-16 h-16 text-cyan-400 mx-auto mb-4" />
              <h3 className="text-2xl mb-3">Team & Solo</h3>
              <p className="text-gray-400">
                Compete individually or form teams with your friends
              </p>
            </div>
            <div className="bg-gray-800/50 border border-cyan-500/30 rounded-lg p-6 text-center">
              <DollarSign className="w-16 h-16 text-cyan-400 mx-auto mb-4" />
              <h3 className="text-2xl mb-3">Prize Pools</h3>
              <p className="text-gray-400">
                Generous prize pools for top performers in every tournament
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
