import { useState } from 'react';
import { User, Mail, Users, Gamepad2, CheckCircle } from 'lucide-react';

export function RegisterPage() {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    playerName: '',
    email: '',
    teamName: '',
    game: '',
    tournament: '',
    discordId: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    // In a real app, this would send data to backend
    setTimeout(() => {
      setSubmitted(false);
      setFormData({
        playerName: '',
        email: '',
        teamName: '',
        game: '',
        tournament: '',
        discordId: ''
      });
    }, 3000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  if (submitted) {
    return (
      <div className="min-h-screen pt-20 flex items-center justify-center px-4">
        <div className="max-w-md w-full bg-gray-800/50 backdrop-blur-sm border border-cyan-500/30 rounded-lg p-8 text-center">
          <CheckCircle className="w-20 h-20 text-green-400 mx-auto mb-6" />
          <h2 className="text-3xl mb-4">Registration Successful!</h2>
          <p className="text-gray-400 text-lg">
            Thank you for registering. We'll send you a confirmation email with further details.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="relative py-20 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-cyan-500/10 to-transparent"></div>
        <div className="relative z-10 max-w-7xl mx-auto text-center">
          <h1 className="text-5xl md:text-7xl mb-6 bg-gradient-to-r from-cyan-400 to-blue-600 bg-clip-text text-transparent">
            Register Now
          </h1>
          <p className="text-xl text-gray-400">
            Join the competition and showcase your skills
          </p>
        </div>
      </section>

      {/* Registration Form */}
      <section className="py-12 px-4 max-w-3xl mx-auto pb-20">
        <div className="bg-gray-800/50 backdrop-blur-sm border border-cyan-500/30 rounded-lg p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Player Name */}
            <div>
              <label htmlFor="playerName" className="block mb-2 text-gray-300">
                <User className="inline w-5 h-5 mr-2 text-cyan-400" />
                Player Name *
              </label>
              <input
                type="text"
                id="playerName"
                name="playerName"
                value={formData.playerName}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 bg-gray-900/50 border border-cyan-500/30 rounded-lg focus:outline-none focus:border-cyan-400 text-white"
                placeholder="Enter your player name"
              />
            </div>

            {/* Email */}
            <div>
              <label htmlFor="email" className="block mb-2 text-gray-300">
                <Mail className="inline w-5 h-5 mr-2 text-cyan-400" />
                Email Address *
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 bg-gray-900/50 border border-cyan-500/30 rounded-lg focus:outline-none focus:border-cyan-400 text-white"
                placeholder="your.email@example.com"
              />
            </div>

            {/* Team Name */}
            <div>
              <label htmlFor="teamName" className="block mb-2 text-gray-300">
                <Users className="inline w-5 h-5 mr-2 text-cyan-400" />
                Team Name (Optional)
              </label>
              <input
                type="text"
                id="teamName"
                name="teamName"
                value={formData.teamName}
                onChange={handleChange}
                className="w-full px-4 py-3 bg-gray-900/50 border border-cyan-500/30 rounded-lg focus:outline-none focus:border-cyan-400 text-white"
                placeholder="Leave blank for solo tournaments"
              />
            </div>

            {/* Tournament Selection */}
            <div>
              <label htmlFor="tournament" className="block mb-2 text-gray-300">
                <Gamepad2 className="inline w-5 h-5 mr-2 text-cyan-400" />
                Select Tournament *
              </label>
              <select
                id="tournament"
                name="tournament"
                value={formData.tournament}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 bg-gray-900/50 border border-cyan-500/30 rounded-lg focus:outline-none focus:border-cyan-400 text-white"
              >
                <option value="">Choose a tournament</option>
                <option value="summer-championship">Summer Championship 2026</option>
                <option value="weekly-showdown">Weekly Showdown</option>
                <option value="pro-league">Pro League Season 3</option>
              </select>
            </div>

            {/* Game Selection */}
            <div>
              <label htmlFor="game" className="block mb-2 text-gray-300">
                <Gamepad2 className="inline w-5 h-5 mr-2 text-cyan-400" />
                Preferred Game *
              </label>
              <select
                id="game"
                name="game"
                value={formData.game}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 bg-gray-900/50 border border-cyan-500/30 rounded-lg focus:outline-none focus:border-cyan-400 text-white"
              >
                <option value="">Select your game</option>
                <option value="battle-royale">Battle Royale</option>
                <option value="fps">FPS Games</option>
                <option value="moba">MOBA</option>
                <option value="racing">Racing</option>
                <option value="fighting">Fighting Games</option>
              </select>
            </div>

            {/* Discord ID */}
            <div>
              <label htmlFor="discordId" className="block mb-2 text-gray-300">
                Discord ID (Optional)
              </label>
              <input
                type="text"
                id="discordId"
                name="discordId"
                value={formData.discordId}
                onChange={handleChange}
                className="w-full px-4 py-3 bg-gray-900/50 border border-cyan-500/30 rounded-lg focus:outline-none focus:border-cyan-400 text-white"
                placeholder="username#1234"
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 text-white px-8 py-4 rounded-lg hover:shadow-lg hover:shadow-cyan-500/50 transition-all"
            >
              Complete Registration
            </button>

            <p className="text-gray-400 text-sm text-center">
              * Required fields. By registering, you agree to our tournament rules and code of conduct.
            </p>
          </form>
        </div>
      </section>
    </div>
  );
}
