import { Shield, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';

export function RulesPage() {
  const generalRules = [
    'All participants must be registered before the tournament start date',
    'Players must maintain respectful behavior towards all participants and staff',
    'Any form of cheating, hacking, or exploiting will result in immediate disqualification',
    'Tournament matches must be played at the scheduled time unless rescheduled with admin approval',
    'All disputes must be reported to tournament administrators within 24 hours',
    'Prize distribution will occur within 30 days of tournament completion'
  ];

  const gameplayRules = [
    'Use of any third-party software or modifications is strictly prohibited',
    'Teams must field their registered roster - no substitutes without prior approval',
    'Screenshots or recordings of match results may be required for verification',
    'In case of technical difficulties, notify admin immediately',
    'Best of 3 format for all matches unless otherwise specified',
    'Default win awarded if opponent doesn\'t show within 15 minutes'
  ];

  const penalties = [
    {
      title: 'Warning',
      icon: AlertTriangle,
      color: 'text-yellow-400',
      description: 'First-time minor infractions or rule violations'
    },
    {
      title: 'Match Loss',
      icon: XCircle,
      color: 'text-orange-400',
      description: 'Repeated violations or unsportsmanlike conduct'
    },
    {
      title: 'Disqualification',
      icon: XCircle,
      color: 'text-red-400',
      description: 'Cheating, harassment, or severe rule violations'
    }
  ];

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="relative py-20 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-cyan-500/10 to-transparent"></div>
        <div className="relative z-10 max-w-7xl mx-auto text-center">
          <Shield className="w-20 h-20 text-cyan-400 mx-auto mb-6" />
          <h1 className="text-5xl md:text-7xl mb-6 bg-gradient-to-r from-cyan-400 to-blue-600 bg-clip-text text-transparent">
            Tournament Rules
          </h1>
          <p className="text-xl text-gray-400">
            Fair play and sportsmanship are our top priorities
          </p>
        </div>
      </section>

      {/* General Rules */}
      <section className="py-12 px-4 max-w-7xl mx-auto">
        <div className="bg-gray-800/50 backdrop-blur-sm border border-cyan-500/30 rounded-lg p-8">
          <h2 className="text-3xl mb-6 text-cyan-400 flex items-center">
            <CheckCircle className="w-8 h-8 mr-3" />
            General Rules
          </h2>
          <ul className="space-y-4">
            {generalRules.map((rule, index) => (
              <li key={index} className="flex items-start">
                <span className="text-cyan-400 mr-3 mt-1">•</span>
                <span className="text-gray-300 text-lg">{rule}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Gameplay Rules */}
      <section className="py-12 px-4 max-w-7xl mx-auto">
        <div className="bg-gray-800/50 backdrop-blur-sm border border-cyan-500/30 rounded-lg p-8">
          <h2 className="text-3xl mb-6 text-cyan-400 flex items-center">
            <Shield className="w-8 h-8 mr-3" />
            Gameplay Rules
          </h2>
          <ul className="space-y-4">
            {gameplayRules.map((rule, index) => (
              <li key={index} className="flex items-start">
                <span className="text-cyan-400 mr-3 mt-1">•</span>
                <span className="text-gray-300 text-lg">{rule}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Penalties */}
      <section className="py-12 px-4 max-w-7xl mx-auto">
        <h2 className="text-4xl text-center mb-12 text-cyan-400">
          Penalty System
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {penalties.map((penalty, index) => (
            <div
              key={index}
              className="bg-gray-800/50 backdrop-blur-sm border border-cyan-500/30 rounded-lg p-6 text-center hover:border-cyan-400/60 transition-all"
            >
              <penalty.icon className={`w-16 h-16 ${penalty.color} mx-auto mb-4`} />
              <h3 className="text-2xl mb-3">{penalty.title}</h3>
              <p className="text-gray-400">{penalty.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Code of Conduct */}
      <section className="py-20 px-4 bg-gradient-to-b from-transparent to-gray-900/50">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl text-center mb-8 text-cyan-400">
            Code of Conduct
          </h2>
          <div className="bg-gray-800/50 backdrop-blur-sm border border-cyan-500/30 rounded-lg p-8">
            <p className="text-gray-300 text-lg leading-relaxed mb-6">
              All participants are expected to maintain the highest standards of sportsmanship and integrity. 
              We are committed to providing a safe, inclusive, and competitive environment for all players.
            </p>
            <p className="text-gray-300 text-lg leading-relaxed mb-6">
              Harassment, discrimination, or toxic behavior of any kind will not be tolerated. 
              This includes but is not limited to verbal abuse, threats, hate speech, or any form of intimidation.
            </p>
            <p className="text-gray-300 text-lg leading-relaxed">
              By participating in EZY tournaments, you agree to abide by all rules and regulations. 
              Tournament administrators reserve the right to make final decisions on all matters.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
