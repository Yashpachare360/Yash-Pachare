import logoImg from 'figma:asset/8863591091e56eaca8cab699c67dd5e73b8e263a.png';

export function Footer() {
  return (
    <footer className="bg-black border-t border-cyan-500/30 py-12 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Logo & Description */}
          <div className="col-span-1 md:col-span-2">
            <img src={logoImg} alt="EZY Logo" className="h-12 w-auto mb-4" />
            <p className="text-gray-400 max-w-md">
              The ultimate gaming tournament platform for competitive players worldwide. 
              Join us and take your gaming to the next level.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg mb-4 text-cyan-400">Quick Links</h3>
            <ul className="space-y-2 text-gray-400">
              <li className="hover:text-cyan-400 cursor-pointer transition-colors">About Us</li>
              <li className="hover:text-cyan-400 cursor-pointer transition-colors">Tournaments</li>
              <li className="hover:text-cyan-400 cursor-pointer transition-colors">Rules</li>
              <li className="hover:text-cyan-400 cursor-pointer transition-colors">FAQ</li>
            </ul>
          </div>

          {/* Social & Legal */}
          <div>
            <h3 className="text-lg mb-4 text-cyan-400">Connect</h3>
            <ul className="space-y-2 text-gray-400">
              <li className="hover:text-cyan-400 cursor-pointer transition-colors">Discord</li>
              <li className="hover:text-cyan-400 cursor-pointer transition-colors">Twitter</li>
              <li className="hover:text-cyan-400 cursor-pointer transition-colors">Instagram</li>
              <li className="hover:text-cyan-400 cursor-pointer transition-colors">YouTube</li>
            </ul>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-cyan-500/30 pt-8 text-center text-gray-400">
          <p>&copy; 2026 EZY Gaming. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
